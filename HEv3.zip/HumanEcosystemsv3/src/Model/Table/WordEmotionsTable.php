<?php
// src/Model/Table/ArticlesTable.php
namespace App\Model\Table;

use Cake\ORM\Table;

class WordEmotionsTable extends Table
{
	public function initialize(array $config)
    {
    }
}
?>